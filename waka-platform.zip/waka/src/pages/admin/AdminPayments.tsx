export { AdminPayments } from './AdminPages'
