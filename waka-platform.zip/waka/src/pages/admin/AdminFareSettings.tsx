export { AdminFareSettings } from './AdminPages'
