export { RideDetail } from './RiderPages'
